place roms here (*.gg)
you can add directories for sorting your roms