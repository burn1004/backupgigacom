place roms here (*.sms)
you can add directories for sorting your roms